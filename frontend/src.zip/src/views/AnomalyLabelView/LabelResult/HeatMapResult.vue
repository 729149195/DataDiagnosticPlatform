<template>
  <span style="display: flex; align-items: center; justify-content: space-between;">
    <span class="title">自动识别和人工标注结果</span>
    <!-- <el-switch v-model="result_switch" style="--el-switch-on-color: #409EFF; --el-switch-off-color: #409EFF"
      active-text="他人标注模式" inactive-text="自己标注" /> -->
    <img src="/image2.png" style="height: 20px;" alt="图例" id="heatmapLegend">
    <div>
      <el-button type="primary" @click="exportHeatMapSvg">
        导出SVG<el-icon class="el-icon--right">
          <Upload />
        </el-icon>
      </el-button>
      <el-button type="primary" @click="exportHeatMapData">
        导出数据<el-icon class="el-icon--right">
          <Upload />
        </el-icon>
      </el-button>
    </div>
  </span>
  <div class="heatmap-section">
    <div v-if="selectedChannels.length === 0">
      <el-empty :image-size="80" description="请选择通道" />
    </div>
    <div v-else class="heatmap-scrollbar">
      <el-scrollbar height="25vh" :always="false">
        <div class="heatmap-container">
          <div v-if="loading" class="progress-wrapper">
            <div class="progress-title">
              <span>热力图数据加载中</span>
              <span class="progress-percentage">{{ loadingPercentage }}%</span>
            </div>
            <el-progress 
              :percentage="loadingPercentage"
              :stroke-width="10"
              :status="loadingPercentage === 100 ? 'success' : ''"
            />
          </div>
          <div class="heatmap-container" :style="{ opacity: loading ? 0 : 1, transition: 'opacity 0.3s ease' }">
            <svg id="heatmap" ref="HeatMapRef" preserveAspectRatio="xMidYMid slice"></svg>
          </div>
        </div>
      </el-scrollbar>
    </div>
    <el-dialog v-model="showAnomalyDialog" title="异常信息" :modal="true" :close-on-click-modal="false"
      @close="handleDialogClose" class="anomaly-dialog">
      <el-scrollbar class="anomaly-scrollbar" height="60vh" :always="false">
        <div v-for="(anomaly, index) in anomalyDialogData" :key="index" class="anomaly-item">
          <el-descriptions :title="`异常 ${index + 1}`" :column="1" border class="anomaly-descriptions">
            <el-descriptions-item v-for="(value, key) in anomaly" :key="key" :label="formatKey(key)">
              {{ formatValue(value, key) }}
            </el-descriptions-item>
          </el-descriptions>
        </div>
      </el-scrollbar>
    </el-dialog>
  </div>
</template>

<script setup>
import * as d3 from 'd3';
import { onMounted, watch, computed, ref, nextTick, onUnmounted } from 'vue';
import { useStore } from 'vuex';
import { ElDialog, ElDescriptions, ElDescriptionsItem } from 'element-plus';
import pLimit from 'p-limit';

const result_switch = ref(true)

// 添加进度相关的响应式变量
const loading = ref(false);
const loadingPercentage = ref(0);
const totalRequests = ref(0);
const completedRequests = ref(0);

// 获取 Vuex store 中的状态
const store = useStore();
const selectedChannels = computed(() => store.state.selectedChannels);
const storePerson = computed(() => store.state.person);
const anomaliesByChannel = computed(() => store.state.anomalies);

// 异常信息对话框的数据和显示状态
const anomalyDialogData = ref([]);
const showAnomalyDialog = ref(false);

// 全局存储所有错误和异常的数据
let errorResults = [];

// 获取 Vuex store 中的数据缓存
const dataCache = computed(() => store.state.dataCache);

// 在 script setup 部分的开头添加 channelDataCache 的计算属性
const channelDataCache = computed(() => store.state.channelDataCache);

//导出功能函数
const HeatMapRef = ref(null)
const exportHeatMapSvg = () => {
  let HeatMap = HeatMapRef.value;
  console.log(HeatMapRef)
  if (HeatMap) {
    // 克隆 SVG 元素并创建一个新的 XML 序列化器
    const clonedSvgElement = HeatMap.cloneNode(true);
    const svgData = new XMLSerializer().serializeToString(clonedSvgElement);

    // 创建一个新的 Image 对象用于 SVG
    const svgImg = new Image();
    const svgBlob = new Blob([svgData], { type: 'image/svg+xml;charset=utf-8' });
    const svgUrl = URL.createObjectURL(svgBlob);

    svgImg.onload = function () {
      // 获取图例图片
      const legendImg = document.getElementById('heatmapLegend');

      legendImg.onload = function () {
        // 创建一个 canvas 元素
        const canvas = document.createElement('canvas');
        const legendWidth = legendImg.width;  // 缩小一半
        const legendHeight = legendImg.height; // 缩小一半
        const padding = 30
        const canvasWidth = Math.max(HeatMap.width.baseVal.value, legendImg.width);
        const canvasHeight = HeatMap.height.baseVal.value + legendImg.height + padding;
        canvas.width = canvasWidth;
        canvas.height = canvasHeight;
        const ctx = canvas.getContext('2d');

        // 绘制图例图片到 canvas 上（在最上面，缩小一半）
        ctx.drawImage(legendImg, canvasWidth-legendWidth - 30, 0, legendWidth, legendHeight);

        // 绘制 SVG 图像到 canvas 上（在图例图片的下方）
        ctx.drawImage(svgImg, 0, legendHeight + padding);

        // 导出为 PNG
        const pngData = canvas.toDataURL('image/png');

        // 创建一个链接并自动下载 PNG
        const link = document.createElement('a');
        link.href = pngData;
        link.download = 'exported_image_with_legend.png';
        link.click();

        // 释放 URL 对象
        URL.revokeObjectURL(svgUrl);
      };

      // 设置图例图片的源
      legendImg.src = legendImg.src; // 重新加载以确保图片正确绘制
    };

    // 设置 SVG 图片的源
    svgImg.src = svgUrl;
  }
}

const exportHeatMapData = () => {
  let HeatMapData = errorResults;

  const jsonData = JSON.stringify(HeatMapData, null, 2);
  const blob = new Blob([jsonData], { type: "application/json" });
  const url = URL.createObjectURL(blob);

  // 创建一个下载链接，并点击下载
  const link = document.createElement("a");
  link.href = url;
  link.download = "error_data.json";
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);

  // 释放 Blob URL
  URL.revokeObjectURL(url);
}


// 辅助函数：判断给定的 errorIdx 是否为异常
function isAnomaly(idx, channelKey) {
  const result = errorResults.find(
    (r) => r.errorIdx === idx && r.channelKey === channelKey
  );
  return result && result.isAnomaly;
}

// 辅助函数：将键名映射为友好的显示名称
function formatKey(key) {
  const keyMapping = {
    person: '责任人',
    diagnostic_name: '诊断名称',
    channel_number: '通道编号',
    error_type: '错误类型',
    x_unit: 'X 单位',
    y_unit: 'Y 单位',
    diagnostic_time: '诊断时间',
    error_description: '错误描述',
    sample_rate: '采样频率',
    id: 'ID',
    channelName: '通道名称',
    startX: '开始时间',
    endX: '结束时间',
    anomalyCategory: '异常类别',
    anomalyDiagnosisName: '异常诊断名称',
    anomalyDescription: '异常描述',
    isStored: '是否已保存',
    // ... 可以添加更多的映射
  };

  return keyMapping[key] || key;
}

// 辅助函数：格式化值的显示
function formatValue(value, key) {
  if (key === 'startX' || key === 'endX') {
    return parseFloat(value).toFixed(4);
  }
  if (key === 'diagnostic_time') {
    return new Date(value).toLocaleString();
  }
  if (value === null || value === undefined || value === '') {
    return '无';
  }
  if (typeof value === 'boolean') {
    return value ? '是' : '否';
  }
  return value;
}

// 处理对话框关闭事件
function handleDialogClose() {
  anomalyDialogData.value = [];
}

// 添加重试和并发限制
const limit = pLimit(50); // 限制并发请求数为5

const retryRequest = async (fn, retries = 3, delay = 1000) => {
    try {
        return await fn();
    } catch (err) {
        if (retries <= 0) throw err;
        await new Promise(resolve => setTimeout(resolve, delay));
        return retryRequest(fn, retries - 1, delay * 2);
    }
};

onMounted(() => {
  // 初始渲染
  if (selectedChannels.value.length > 0) {
    renderHeatmap(selectedChannels.value);
  }
});

// 合并所有的监听逻辑到一个 watch 中
const debounceRender = ref(null);

watch(
  [() => channelDataCache.value, selectedChannels, anomaliesByChannel],
  async ([newCache, newChannels, newAnomalies], [oldCache, oldChannels, oldAnomalies]) => {
    // 如果没有选中的通道，不进行渲染
    if (!newChannels || newChannels.length === 0) {
      return;
    }

    // 检查是否有新通道被添加
    const hasNewChannels = !oldChannels || 
      newChannels.length !== oldChannels.length || 
      newChannels.some(newChannel => 
        !oldChannels.find(oldChannel => 
          oldChannel.channel_key === newChannel.channel_key
        )
      );

    // 检查是否只是因为懒加载导致的更新
    const isLazyLoadUpdate = !hasNewChannels && oldChannels && 
      newChannels.length === oldChannels.length && 
      newChannels.every((channel, index) => 
        channel.channel_key === oldChannels[index].channel_key
      );

    // 如果是懒加载更新且没有新的异常数据，不重新渲染热力图
    if (isLazyLoadUpdate && !newAnomalies) {
      return;
    }

    // 检查是否只是异常数据发生变化
    const isOnlyAnomalyChange = !hasNewChannels && oldChannels && 
      JSON.stringify(newChannels) === JSON.stringify(oldChannels) && 
      JSON.stringify(newAnomalies) !== JSON.stringify(oldAnomalies);

    // 使用防抖来避免频繁渲染
    if (debounceRender.value) {
      clearTimeout(debounceRender.value);
    }

    // 创建一个新的 Promise 来处理渲染
    const renderPromise = new Promise((resolve) => {
      debounceRender.value = setTimeout(async () => {
        try {
          await nextTick();
          // 如果是新通道添加，强制重新渲染所有数据
          await renderHeatmap(newChannels, isOnlyAnomalyChange && !hasNewChannels);
          resolve();
        } catch (error) {
          console.error('Error in debounced renderHeatmap:', error);
          loading.value = false;
          loadingPercentage.value = 0;
          resolve();
        }
      }, isOnlyAnomalyChange && !hasNewChannels ? 0 : 300); // 如果只是异常数据变化且没有新通道，立即渲染
    });

    await renderPromise;
  },
  { 
    deep: true,
    immediate: true 
  }
);

// 组件卸载时清理定时器
onUnmounted(() => {
  if (debounceRender.value) {
    clearTimeout(debounceRender.value);
  }
});

// 添加数据处理函数
const processDataTo1KHz = (data) => {
  if (!data || !data.X_value || !data.Y_value) {
    return data;
  }

  const targetFrequency = 1000; // 1KHz
  const timeStep = 1 / targetFrequency;
  
  // 计算当前采样率
  const currentTimeStep = (data.X_value[data.X_value.length - 1] - data.X_value[0]) / (data.X_value.length - 1);
  const currentFrequency = 1 / currentTimeStep;
  
  // 如果当前频率接近1KHz，直接返回原始数据
  if (Math.abs(currentFrequency - targetFrequency) < 1) {
    return data;
  }

  // 创建新的时间点数组
  const startTime = data.X_value[0];
  const endTime = data.X_value[data.X_value.length - 1];
  const newXValues = [];
  const newYValues = [];
  
  let currentTime = startTime;
  let currentIndex = 0;
  
  while (currentTime <= endTime && currentIndex < data.X_value.length) {
    // 找到���前时间点对应的索引
    while (currentIndex < data.X_value.length - 1 && data.X_value[currentIndex + 1] < currentTime) {
      currentIndex++;
    }
    
    // 线性插值
    if (currentIndex < data.X_value.length - 1) {
      const x0 = data.X_value[currentIndex];
      const x1 = data.X_value[currentIndex + 1];
      const y0 = data.Y_value[currentIndex];
      const y1 = data.Y_value[currentIndex + 1];
      
      const ratio = (currentTime - x0) / (x1 - x0);
      const interpolatedY = y0 + ratio * (y1 - y0);
      
      newXValues.push(currentTime);
      newYValues.push(interpolatedY);
    }
    
    currentTime += timeStep;
  }

  return {
    X_value: newXValues,
    Y_value: newYValues,
    X_unit: data.X_unit,
    Y_unit: data.Y_unit
  };
};

async function renderHeatmap(channels, isOnlyAnomalyChange = false) {
  try {
    // 如果没有通道数据，直接返回
    if (!channels || channels.length === 0) {
      loading.value = false;
      return;
    }

    // 重置进度状态
    loading.value = true;
    loadingPercentage.value = 0;
    completedRequests.value = 0;
    
    const heatmap = d3.select('#heatmap');
    heatmap.selectAll('*').remove();

    // 始终重置错误数据，确保新通道的数据能被正确处理
    errorResults = [];

    // 计算总请求数
    totalRequests.value = channels.reduce((total, channel) => total + channel.errors.length, 0);
    
    // 添加异常数据到总请求数
    for (const channel of channels) {
      const channelKey = `${channel.channel_name}_${channel.shot_number}`;
      const channelAnomalies = anomaliesByChannel.value[channelKey] || [];
      totalRequests.value += channelAnomalies.length;
    }

    if (totalRequests.value === 0) {
      loading.value = false;
      loadingPercentage.value = 100;
      return;
    }

    // 计算所有通道数据的 X 值范围
    let globalXMin = Infinity;
    let globalXMax = -Infinity;
    
    // 使用 Map 缓存已处理的通道数据
    const processedChannels = new Map();
    
    // 遍历 channelDataCache 中的所有数据来计算全局 X 范围
    for (const channel of channels) {
      const channelKey = `${channel.channel_name}_${channel.shot_number}`;
      // 从 channelDataCache.value 中获取数据
      const channelData = channelDataCache.value[channelKey];
      
      if (channelData && channelData.X_value) {
        // 处理数据到1KHz
        const processedData = processDataTo1KHz(channelData);
        let xValues = processedData.X_value;
        
        const localMin = Math.min(...xValues);
        const localMax = Math.max(...xValues);
        
        globalXMin = Math.min(globalXMin, localMin);
        globalXMax = Math.max(globalXMax, localMax);
        
        // 缓存处理后的数据
        processedChannels.set(channelKey, {
          ...processedData,
          localMin,
          localMax
        });
      }
    }

    // 如果没有找到有效数据,使用默认
    if (globalXMin === Infinity || globalXMax === -Infinity) {
      globalXMin = -2;
      globalXMax = 6;
    }

    const Domain = [globalXMin, globalXMax];
    const step = (Domain[1] - Domain[0]) / 16;
    const rectNum = Math.round((Domain[1] - Domain[0]) / step);

    const visData = {}; // { [channelKey]: data array }
    const errorColors = {}; // { [errorIdx]: color }
    let errorIdxCounter = 1;

    // 使用 Map 存储错误数据
    const errorDataMap = new Map();
    const errorPromises = [];

    // 首先处理所有通道的错误数据
    for (const channel of channels) {
      const channelKey = `${channel.channel_name}_${channel.shot_number}`;
      const channelType = channel.channel_type;
      
      // 初始化该通道的可视化数据
      if (!visData[channelKey]) {
        visData[channelKey] = Array(rectNum).fill().map(() => []);
      }

      // 处理错误数据
      for (const [errorIndex, error] of channel.errors.entries()) {
        const errorIdxCurrent = errorIdxCounter++;
        errorColors[errorIdxCurrent] = error.color;
        const errorName = error.error_name;

        const errorCacheKey = `${channelKey}-error-${errorName}-${errorIndex}-heatmap`;

        if (dataCache.value.has(errorCacheKey)) {
          const errorData = dataCache.value.get(errorCacheKey);
          errorDataMap.set(errorIdxCurrent, {
            channelKey,
            errorIdx: errorIdxCurrent,
            errorData: errorData,
            isAnomaly: false
          });
          
          processErrorData(errorData, channelKey, errorIdxCurrent, visData, rectNum, Domain, step);
          
          completedRequests.value++;
          loadingPercentage.value = Math.round((completedRequests.value / totalRequests.value) * 100);
          continue;
        }

        const params = {
          channel_key: channelKey,
          channel_type: channelType,
          error_name: errorName,
          error_index: errorIndex,
        };

        const errorPromise = limit(() => retryRequest(async () => {
          try {
            const response = await fetch(
              `http://localhost:5000/api/error-data/?${new URLSearchParams(params).toString()}`
            );
            if (!response.ok) {
              throw new Error(`HTTP error! status: ${response.status}`);
            }
            const errorData = await response.json();
            
            dataCache.value.set(errorCacheKey, errorData);
            
            errorDataMap.set(errorIdxCurrent, {
              channelKey,
              errorIdx: errorIdxCurrent,
              errorData: errorData,
              isAnomaly: false
            });

            processErrorData(errorData, channelKey, errorIdxCurrent, visData, rectNum, Domain, step);

            completedRequests.value++;
            loadingPercentage.value = Math.round((completedRequests.value / totalRequests.value) * 100);
            
            return { channelKey, errorIdx: errorIdxCurrent, errorData };
          } catch (err) {
            console.warn(
              `Failed to fetch error data for ${errorName} at index ${errorIndex}:`,
              err
            );
            return null;
          }
        }));

        errorPromises.push(errorPromise);
      }

      // 立即处理该通道的异常数据
      const channelAnomalies = anomaliesByChannel.value[channelKey] || [];
      for (const anomaly of channelAnomalies) {
        const anomalyErrorIdxCurrent = errorIdxCounter++;
        errorColors[anomalyErrorIdxCurrent] = 'orange';

        errorResults.push({
          channelKey,
          errorIdx: anomalyErrorIdxCurrent,
          errorData: anomaly,
          isAnomaly: true,
        });

        const timeStep = 0.001;
        const startX = Math.floor(parseFloat(anomaly.startX) / timeStep) * timeStep;
        const endX = Math.ceil(parseFloat(anomaly.endX) / timeStep) * timeStep;
        
        const left = Math.floor((startX - Domain[0]) / step);
        const right = Math.floor((endX - Domain[0]) / step);
        
        for (let i = left; i <= right && i < rectNum; i++) {
          if (i >= 0) {
            visData[channelKey][i].push(anomalyErrorIdxCurrent);
          }
        }

        completedRequests.value++;
        loadingPercentage.value = Math.round((completedRequests.value / totalRequests.value) * 100);
      }
    }

    // 等待所有错误数据加载完成
    await Promise.allSettled(errorPromises);
    
    // 将所有错误数据添加到 errorResults
    errorDataMap.forEach(value => {
      errorResults.push(value);
    });

    // 准备绘图数据
    const channelKeys = channels.map(
      (channel) => `${channel.channel_name}_${channel.shot_number}`
    );
    const channelNames = channels.map(
      (channel) => `${channel.channel_name} / ${channel.shot_number}`
    );

    // 确保所有通道都有数据
    channelKeys.forEach(key => {
      if (!visData[key]) {
        visData[key] = Array(rectNum).fill().map(() => []);
      }
    });

    const visDataArrays = channelKeys.map((key) => visData[key]);

    // 准备X轴刻度
    const xAxisTick = [];
    for (let i = Domain[0]; i <= Domain[1]; i += step) {
      xAxisTick.push(i.toFixed(1)); // 保留一位小数
    }

    // 设置绘图尺寸
    const margin = { top: 8, right: 10, bottom: 100, left: 5 };
    const width = 1080 - margin.left - margin.right;
    const rectH = 25; // 固定每个矩形的高度
    const XaxisH = 20;
    const YaxisW = 140; // 调整宽度以适应通道名和炮号
    const height = rectH * channelNames.length + XaxisH;

    const rectW = (width - YaxisW - margin.left) / rectNum;

    // 动态设置 SVG 的 viewBox 属性
    heatmap
      .attr(
        'viewBox',
        `0 0 ${width + margin.left + margin.right + YaxisW / 2} ${height + margin.top + margin.bottom}`
      )
      .attr('preserveAspectRatio', 'xMidYMid slice') // 修改为 'slice' 以确保自适应
      .attr('width', '100%') // 设置宽度为 100%
      .attr('height', height + margin.top + margin.bottom); // 设置高度

    // 绘制Y轴通道名称和炮号
    heatmap
      .selectAll('.channelName')
      .data(channelNames)
      .join('text')
      .attr('class', 'channelName')
      .attr('x', YaxisW - margin.left - 5)
      .attr(
        'y',
        (d, i) =>
          rectH * 0.5 + 5 + XaxisH + i * (rectH + margin.top)
      )
      .style('text-anchor', 'end')
      .text((d) => d);

    // 绘制X轴刻度
    heatmap
      .selectAll('.xTick')
      .data(xAxisTick)
      .join('text')
      .attr('class', 'xTick')
      .attr('x', (d, i) => YaxisW + i * (rectW + margin.left))
      .attr('y', XaxisH - 5)
      .style('text-anchor', 'middle')
      .style('font-size', '10px')
      .text((d) => d);

    // 绘制热力图矩形
    heatmap
      .selectAll('.heatmapRectG')
      .data(visDataArrays)
      .join('g')
      .attr('class', 'heatmapRectG')
      .attr(
        'transform',
        (d, i) => `translate(${YaxisW}, ${XaxisH + i * (rectH + margin.top)})`
      )
      .each(function (d, i) {
        const channel = channels[i];
        const channelKey = `${channel.channel_name}_${channel.shot_number}`;

        // 在该通道的 g 元素中绘制矩形
        d3.select(this)
          .selectAll('.heatmapRect')
          .data(d)
          .join('rect')
          .attr('class', 'heatmapRect')
          .attr('x', (d, j) => j * (rectW + margin.left))
          .attr('y', 0)
          .attr('width', rectW)
          .attr('height', rectH)
          .attr('rx', 3)
          .attr('ry', 3)
          .attr('fill', 'none')
          .attr('stroke', (d) => {
            if (d.length > 0) {
              // 检查是否包含异常
              const hasAnomaly = d.some(idx => {
                const result = errorResults.find(r => r.errorIdx === idx && r.channelKey === channelKey);
                return result && result.isAnomaly;
              });
              
              if (hasAnomaly) {
                return 'orange';
              }
              
              const nonAnomalyIdx = d.find(idx => {
                const result = errorResults.find(r => r.errorIdx === idx && r.channelKey === channelKey);
                return result && !result.isAnomaly;
              });

              if (nonAnomalyIdx) {
                const errorData = errorResults.find(
                  result => result && 
                  result.errorIdx === nonAnomalyIdx && 
                  result.channelKey === channelKey
                );
                if (errorData) {
                  if (errorData.errorData.person !== storePerson.value) {
                    return errorColors[nonAnomalyIdx];
                  }
                  return channel.errors.length > 1 ? '#ccc' : errorColors[nonAnomalyIdx];
                }
              }
            }
            return 'none';
          })
          .attr('stroke-width', (d) => d.length > 0 ? 3 : 0)
          .attr('stroke-dasharray', (d) => {
            if (d.length > 0) {
              // 检查是否包含异常
              const hasAnomaly = d.some(idx => {
                const result = errorResults.find(r => r.errorIdx === idx && r.channelKey === channelKey);
                return result && result.isAnomaly;
              });
              
              if (hasAnomaly) {
                return '0';
              }
              
              const nonAnomalyIdx = d.find(idx => {
                const result = errorResults.find(r => r.errorIdx === idx && r.channelKey === channelKey);
                return result && !result.isAnomaly;
              });

              if (nonAnomalyIdx) {
                const errorData = errorResults.find(
                  result => result && 
                  result.errorIdx === nonAnomalyIdx && 
                  result.channelKey === channelKey
                );
                if (errorData) {
                  if (errorData.errorData.person !== storePerson.value) {
                    return '4 2';
                  }
                  return channel.errors.length > 1 ? '4 2' : '0';
                }
              }
            }
            return '0';
          })
          .attr('cursor', 'pointer')
          .on('click', function (event, dRect) {
            event.stopPropagation();

            const errorIdxs = dRect;
            const errorsInRect = errorIdxs
              .map((idx) =>
                errorResults.find(
                  (result) =>
                    result &&
                    result.errorIdx === idx &&
                    result.channelKey === channelKey
                )
              )
              .filter((e) => e);

            // 提取并过滤所有错误信息
            const filteredErrorsInRect = errorsInRect.map((e) => {
              const errorData = e.errorData;
              const { X_value_error, Y_value_error, ...filteredData } = errorData;
              // 将不存在的字段设置为 'unknown'
              Object.keys(filteredData).forEach((key) => {
                if (
                  filteredData[key] === undefined ||
                  filteredData[key] === null
                ) {
                  filteredData[key] = 'unknown';
                }
              });
              return filteredData;
            });

            // 去除重复的异常信息
            const uniqueFilteredErrorsInRect = filteredErrorsInRect.filter(
              (item, index, self) =>
                index ===
                self.findIndex(
                  (t) => JSON.stringify(t) === JSON.stringify(item)
                )
            );

            if (uniqueFilteredErrorsInRect.length > 0) {
              anomalyDialogData.value = uniqueFilteredErrorsInRect;
              showAnomalyDialog.value = true;
            } else {
              showAnomalyDialog.value = false;
            }
          });

        // 在大的矩形内绘制小的矩形
        d3.select(this)
          .selectAll('.innerRect')
          .data(d)
          .join('rect')
          .attr('class', 'innerRect')
          .attr('x', (d, j) => j * (rectW + margin.left) + rectW * 0.1)
          .attr('y', rectH * 0.1)
          .attr('width', rectW * 0.8)
          .attr('height', rectH * 0.8)
          .attr('rx', 2)
          .attr('ry', 2)
          .attr('fill', (d) => {
            if (d.length > 0) {
              // 存在错误或异常
              if (channel.errors.length > 1) {
                return '#999999'; // 多个错误，使用灰色
              } else {
                const nonAnomalyIdx = d.find(
                  (idx) => !isAnomaly(idx, channelKey)
                );
                const errorData = errorResults.find(
                  (result) =>
                    result &&
                    result.errorIdx === nonAnomalyIdx &&
                    result.channelKey === channelKey
                );
                if (errorData && errorData.errorData.person === 'machine') {
                  return errorColors[nonAnomalyIdx];
                } else {
                  return '#f5f5f5';
                }
              }
            } else {
              return '#f5f5f5'; // 正常数据颜色
            }
          })
          .attr('cursor', 'pointer')
          .on('click', function (event, dRect) {
            event.stopPropagation();

            const errorIdxs = dRect;
            const errorsInRect = errorIdxs
              .map((idx) =>
                errorResults.find(
                  (result) =>
                    result &&
                    result.errorIdx === idx &&
                    result.channelKey === channelKey
                )
              )
              .filter((e) => e);

            // 提取并过滤所有错误信息
            const filteredErrorsInRect = errorsInRect.map((e) => {
              const errorData = e.errorData;
              const { X_value_error, Y_value_error, ...filteredData } = errorData;
              // 将不存在的字段设置为 'unknown'
              Object.keys(filteredData).forEach((key) => {
                if (
                  filteredData[key] === undefined ||
                  filteredData[key] === null
                ) {
                  filteredData[key] = 'unknown';
                }
              });
              return filteredData;
            });

            // 去除重复的异常信息
            const uniqueFilteredErrorsInRect = filteredErrorsInRect.filter(
              (item, index, self) =>
                index ===
                self.findIndex(
                  (t) => JSON.stringify(t) === JSON.stringify(item)
                )
            );

            if (uniqueFilteredErrorsInRect.length > 0) {
              anomalyDialogData.value = uniqueFilteredErrorsInRect;
              showAnomalyDialog.value = true;
            } else {
              showAnomalyDialog.value = false;
            }
          });
      });

    // 在所有数据处理完成后
    await Promise.allSettled(errorPromises);
    
    // 确保进度条显示完成
    loadingPercentage.value = 100;
    // 短暂延迟后隐藏加载状态���让用户能看到100%的进度
    setTimeout(() => {
      loading.value = false;
    }, 500);

  } catch (error) {
    console.error('Error in renderHeatmap:', error);
    loading.value = false;
    loadingPercentage.value = 0;
  }
}

// 修改处理错误数据的辅助函数
function processErrorData(errorData, channelKey, errorIdx, visData, rectNum, Domain, step) {
  const X_value_error = errorData['X_value_error'];
  
  // 对于每个错误区间
  for (const idxList of X_value_error) {
    if (!Array.isArray(idxList) || idxList.length === 0) {
      continue;
    }
    
    // 处理错误数据到1KHz
    const processedErrorData = processDataTo1KHz({
      X_value: idxList,
      Y_value: new Array(idxList.length).fill(0) // Y值在这里不重要，我们只需要X值
    });
    
    const left = Math.floor((processedErrorData.X_value[0] - Domain[0]) / step);
    const right = Math.floor((processedErrorData.X_value[processedErrorData.X_value.length - 1] - Domain[0]) / step);
    
    for (let i = left; i <= right; i++) {
      if (i >= 0 && i < rectNum) {
        visData[channelKey][i].push(errorIdx);
      }
    }
  }
}
</script>

<style scoped lang="scss">
.heatmap-section {
  display: flex;
  flex-direction: column;
  width: 100%;
  user-select: none;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
}

.heatmap-scrollbar {
  width: 100%;
  flex: 1;
}

.heatmap-container {
  width: 100%;
  height: 100%;
  overflow: hidden; // 确保没有溢出
}

#heatmap {
  width: 100%;
  height: 100%;
}

.anomaly-dialog {
  width: 80% !important; // 根据需要调整对话框宽度
  max-width: 100%;
}

.anomaly-scrollbar {
  width: 100%;
}

.anomaly-item {
  width: 100%;
}

.anomaly-descriptions {
  width: 100%;
}

.title {
  color: #999;
}

.channelName {
  font-size: 12px;
  fill: #333;
}

.xTick {
  font-size: 10px;
  fill: #666;
}

.progress-wrapper {
  margin: 20px 0;
  padding: 0 10px;
}

.progress-title {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 4px;
  font-size: 13px;
  color: #606266;
}

.progress-percentage {
  font-weight: bold;
  color: #409EFF;
}

:deep(.el-progress-bar__outer) {
  background-color: #f0f2f5;
  border-radius: 4px;
}

:deep(.el-progress-bar__inner) {
  transition: width 0.3s ease;
  border-radius: 4px;
}

:deep(.el-progress--line) {
  margin-bottom: 0;
}

/* 修改进度条成功状态的颜色 */
:deep(.el-progress.is-success .el-progress-bar__inner) {
  background-color: #67C23A;
}

:deep(.el-progress-bar__innerText) {
  font-size: 12px;
  margin: 0 5px;
  color: #fff;
}

/* 让输入框内的文字可以选中 */
.el-input {
  user-select: text;
  -webkit-user-select: text;
  -moz-user-select: text;
  -ms-user-select: text;
}

/* 让输入框内的文字可以选中 */
.el-input__inner {
  user-select: text;
  -webkit-user-select: text;
  -moz-user-select: text;
  -ms-user-select: text;
}

/* 让对话框中的输入框文字可以���中 */
.el-dialog .el-input {
  user-select: text;
  -webkit-user-select: text;
  -moz-user-select: text;
  -ms-user-select: text;
}
</style>
