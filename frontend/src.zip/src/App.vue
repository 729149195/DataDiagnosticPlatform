<script setup>
import { RouterView } from 'vue-router'
import zhCn from 'element-plus/dist/locale/zh-cn.mjs'

</script>

<template>
 <el-config-provider :locale="zhCn">
    <RouterView />
  </el-config-provider>
</template>

<style>
</style>